//
//  Pets.hpp
//  c_plus_plus
//
//  Created by Khusain on 25.10.2023.
//

#ifndef Pets_hpp
#define Pets_hpp

#include <iostream>

#endif /* Pets_hpp */
