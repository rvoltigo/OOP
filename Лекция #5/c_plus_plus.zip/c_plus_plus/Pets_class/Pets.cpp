//
//  Pets.cpp
//  c_plus_plus
//
//  Created by Khusain on 25.10.2023.
//

#include "Pets.hpp"

using namespace std;

class Pets {
protected:
    string name;
    
public:
    Pets(string name) {
        this->name = name;
    }
    
    string get_name() {
        return name;
    }
    
    void voice() {
        cout << "Voice" << endl;
    }
};
