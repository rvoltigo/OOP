//
//  main.cpp
//  c_plus_plus
//
//  Created by Khusain on 17.10.2023.
//

#include <iostream>
#include "Pets_class/Pets.cpp"

using namespace std;

class Cats: public Pets {
public:
    Cats(string name):
    Pets(name) {
    }
    
    int frags() {
        return 1;
    }
    
    void voice() {
        cout << "Myaw" << endl;
    }
};

class Dogs: public Pets {
private:
    int age;

public:
    Dogs(string name, int age):
    Pets(name) {
        this->age = age;
    }
    
    int get_age() {
        return age;
    }
    
    void print() {
        cout << name << endl;
    }
};

int main() {
    
    Pets pet = Pets("home pet");
    pet.voice();
    
//    Dogs ice = Dogs("Ice", 12);
    
//    vasya.voice();
    
    return 0;
}
